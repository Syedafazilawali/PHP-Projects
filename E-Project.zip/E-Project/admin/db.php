<?php

$con = mysqli_connect('localhost','root','','registration_db');

	/*if($con)
	{
		echo"connection established !!";
		}
	else
	{
		echo"connection faild!!!";
		}*/

?>