<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>db.php</title>
</head>

<body>
<?php
$con = mysqli_connect('localhost','root','','registration_db');

/*if($con)
{
	echo"connection established !!";
}
else

{
	echo"connection Failed";
}*/
?>
</body>
</html>